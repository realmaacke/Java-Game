package builder.management;

public class KeyBindManager {
    public enum keybindMode {
        game,
        other
    };

    public void LoadKeyBinds() {
        
    }
}
