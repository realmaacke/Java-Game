package builder.enums;

public enum PlayerState {
    IDLE,
    MOVING,
    CASTING,
    STUNNED
}
