package builder.objects;

import org.joml.Vector3f;

public class Collider2D {
    public Vector3f min = new Vector3f();
    public Vector3f max = new Vector3f();
}
