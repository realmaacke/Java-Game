package builder.base;

public class Config {
    // Map management
    public static String maps = "maps/maps.json";

    // Window management
    public static int width = 1280;
    public static int height = 720;

    public static String title = "Game title";

}
