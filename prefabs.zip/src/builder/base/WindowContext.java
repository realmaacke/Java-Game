package builder.base;

public class WindowContext {
    public static long window;

    public static int width = 1280;
    public static int height = 720;

    public static double mouseX;
    public static double mouseY;

}
